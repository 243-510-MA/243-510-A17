/*
 * File:   time_delay.h
 * Author: http://pic18fxx.blogspot.com 
 */
#ifndef TIME_DELAY_H
#define	TIME_DELAY_H

void Delay_ms(unsigned int count);
void Delay_us(unsigned int count);

#endif	/* TIME_DELAY_H */

